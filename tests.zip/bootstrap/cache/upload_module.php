<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Upload\\Providers\\UploadServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Upload\\Providers\\UploadServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);