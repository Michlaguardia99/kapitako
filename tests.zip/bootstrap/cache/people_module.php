<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\People\\Providers\\PeopleServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\People\\Providers\\PeopleServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);