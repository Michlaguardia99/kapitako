<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Adjustment\\Providers\\AdjustmentServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Adjustment\\Providers\\AdjustmentServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);