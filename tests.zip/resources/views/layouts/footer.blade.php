<footer class="c-footer">
    <div>{!! settings()->footer_text !!}</div>

    <div class="mfs-auto d-md-down-none">Powered by&nbsp;<a href="https://laravel.com" target="_blank">Laravel</a></div>
</footer>
