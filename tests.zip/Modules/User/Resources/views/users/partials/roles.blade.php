@foreach($roles as $role)
    <span class="badge badge-primary">{{ $role }}</span>
@endforeach
